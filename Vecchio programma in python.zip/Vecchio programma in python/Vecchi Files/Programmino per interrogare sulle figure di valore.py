###################################################################
#                                                                 #
# http://www.codeskulptor.org/#user43_58nvhj10HS_1.py             #
#                                                                 #
# Programma per interrogare sulla notazione e le figure di valore #
#                                                                 #
# Autore: Paolo Maria Guardiani                                   # 
#                                                                 #
###################################################################